import React, {useCallback, useEffect, useState} from 'react'
import {useEditor, useNode, Element} from '@craftjs/core'
import {Mail, Phone, Person} from '@material-ui/icons'
import ContentEditable, {ContentEditableEvent} from 'react-contenteditable'
import {Container} from '@material-ui/core'
import {AddOptSubmits} from '../../../services'
import submitOptinForm from '../../../services/SubmitOptinForm'
import {AxiosError} from 'axios'
import {useParams, useHistory} from 'react-router-dom'
import FormSettings from './FormSettings'
import InputComponent from './InputComonent'
import Button, {ButtonSize} from '../Button'
import Text from '../Text'
import {useSelector} from 'react-redux'
import {AppState} from '../../../reducers'

const defaultProps = {
	padding: ['0', '0', '0', '0'],
	margin: ['0', '0', '0', '0'],
	background: {r: 255, g: 255, b: 255, a: 1},
	color: {r: 0, g: 0, b: 0, a: 1},
	shadow: 0,
	radius: 0,
	targetEmail: '',
	funnelId: '',
}
const OptinForm = (props: any) => {
	const {funnelTitle} = useParams()

	const history = useHistory()

	const {
		connectors: {connect},
		setProp,
	} = useNode()

	const {enabled} = useEditor((state, _) => ({
		enabled: state.options.enabled,
	}))
	const [text, setText] = useState<string>('Sign up')

	const handleChange = useCallback(
		(e: ContentEditableEvent) => {
			setText(e.target.value)
		},
		[setText]
	)

	const [optData, setOptData] = useState<AddOptSubmits>()

	const isDisabled: boolean = Boolean(
		optData?.email === '' || optData?.fullname === '' || optData?.phone === ''
	)

	const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		setOptData((prevState) => ({...prevState, [e.target.id]: e.target.value}))
	}

	const handleSubmit = (e: React.FormEvent) => {
		e.preventDefault()

		submitOptinForm({...optData, funnelTitle: funnelTitle})
			.then((res) => {
				console.log(res)
			})
			.catch((err: AxiosError) => {
				if (err.response) {
					console.error(err.response.data.error)
				} else {
					console.error(err)
				}
			})
	}

	const {background, color, padding, margin, shadow, radius} = props

	const {user} = useSelector((state: AppState) => state.auth)
	const {funnels} = useSelector((state: AppState) => state.funnels)

	const funnelId = funnels.find((f) => f.title === funnelTitle)._id

	useEffect(() => {
		if (props.targetEmail) {
			setProp((props) => (props.targetEmail = user.email))
		}
		if (props.funnelId) {
			setProp((props) => (props.funnelId = funnelId))
		}
	}, [])
	return (
		<div
			ref={connect}
			style={{
				background: `rgba(${Object.values(background)})`,
				color: `rgba(${Object.values(color)})`,
				padding: `${padding[0]}px ${padding[1]}px ${padding[2]}px ${padding[3]}px`,
				margin: `${margin[0]}px ${margin[1]}px ${margin[2]}px ${margin[3]}px`,
				boxShadow:
					shadow === 0
						? 'none'
						: `0px 3px 100px ${shadow}px rgba(0, 0, 0, 0.13)`,
				borderRadius: `${radius}px`,
			}}
		>
			<div className="w-full">
				{/* <div className="bg-white py-8 shadow sm:rounded-lg mt-4 mb-4"> */}
				<form className="space-y-6 px-4 py-2">
					{/* <div>
						<label
							htmlFor="fullname"
							className="block text-sm font-medium text-gray-700"
						>
							Fullname
						</label>
						<div className="mt-1 relative rounded-md shadow-sm">
							<div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
								<Person className="h-5 w-5 text-gray-400" aria-hidden="true" />
							</div>
							<input
								disabled={enabled}
								type="text"
								id="fullname"
								value={optData?.fullname}
								onChange={handleFormChange}
								className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
								placeholder="Mr. Magic"
							/>
						</div>
					</div>
					<div>
						<label
							htmlFor="email"
							className="block text-sm font-medium text-gray-700"
						>
							Email Address
						</label>
						<div className="mt-1 relative rounded-md shadow-sm">
							<div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
								<Mail className="h-5 w-5 text-gray-400" aria-hidden="true" />
							</div>
							<input
								disabled={enabled}
								type="email"
								value={optData?.email}
								onChange={handleFormChange}
								name="email"
								id="email"
								className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
								placeholder="you@example.com"
							/>
						</div>
					</div>
					<div>
						<label
							htmlFor="phone"
							className="block text-sm font-medium text-gray-700"
						>
							Phone number
						</label>
						<div className="mt-1 relative rounded-md shadow-sm">
							<div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
								<Phone className="h-5 w-5 text-gray-400" aria-hidden="true" />
							</div>
							<input
								disabled={enabled}
								type="text"
								value={optData?.phone}
								onChange={handleFormChange}
								id="phone"
								className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10  sm:text-sm border-gray-300 rounded-md"
								placeholder="000-00-0000"
							/>
						</div>
						<div className="mt-3 relative rounded-md shadow-sm">
							<button
								disabled={enabled || isDisabled}
								type="submit"
								className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
							>
								<ContentEditable
									html={text}
									onChange={handleChange}
									disabled={!enabled}
								/>
							</button>
						</div>
					</div> */}
					<Element is={Text} id="form_title" text="Get in touch" />
					<div className="w-2/3 mx-auto space-y-3">
						<Element
							is={InputComponent}
							id="input_component1"
							placeholder="Name"
							label="Name"
							name="name"
							iconSrc={
								'https://cdn-icons.flaticon.com/png/128/1144/premium/1144760.png'
							}
						/>
						<Element
							is={InputComponent}
							id="input_component2"
							placeholder="Email Address"
							name="email"
							label="Email Address"
							type={'email'}
							iconSrc={
								'https://cdn-icons.flaticon.com/png/128/542/premium/542638.png?token=exp=1653993263~hmac=07b92684d83797c33717ab9e9d8e3fc6'
							}
						/>
						<Element
							is={InputComponent}
							id="input_component3"
							label="Phone Number"
							placeholder="Telephone Number"
							name="phone"
							type={'tel'}
							iconSrc={
								'https://cdn-icons.flaticon.com/png/128/1959/premium/1959251.png?token=exp=1653993293~hmac=accbfd6745279201654fa1e056b733cf'
							}
						/>
						<Element
							is={Button}
							id="submit_button"
							text="Send"
							type="submit"
							size={ButtonSize.SMALL}
						/>
					</div>
				</form>
				{/* </div> */}
			</div>
		</div>
	)
}

OptinForm.craft = {
	displayName: 'Leads form',
	props: defaultProps,
	related: {toolbar: FormSettings},
}

export default OptinForm
